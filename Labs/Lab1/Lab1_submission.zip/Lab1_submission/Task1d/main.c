


#include <stdio.h>

void converter();
void minus_conv(int i, char* path);
void plus_conv(int i, char* path);
void getParams(char* args,int argc,char** argv);

int main(int argc, char* argv[]){
    if (argc == 1)
        converter();
    else if (argc == 3){
        
        //get input path: 
        char* p = argv[2];
        // get the relevant part:
        char c = 1;
        char path[1086];
        int i = 2;
        while (c != 0){ 
            path[i - 2] = p[i];
            i++;
            c = p[i];
        }

        char par[3];
        getParams(par, argc, argv);
        int int_jump;

        // Transformation without sscanf:
        char d = par[2];
        if (d > 59)
            d = d - 55;
        else
            d = d - 48;
        
        int_jump = (int) d;

        if (par[0] == '+')
            plus_conv(int_jump, path);
        else
            minus_conv(int_jump, path); 
    }
}